<div refs="editor-toolbox@tab-content" data-tab-content="contents" class="toolbox-tab-content">
    <h4><?php echo e(trans('entities.page_contents')); ?></h4>

    <div component="toolbox-contents" class="comment-container-compact px-l">
        <p class="text-muted small mb-m"><?php echo e(trans('entities.page_contents_info')); ?></p>
        <p class="text-muted small mb-m" refs="toolbox-contents@none" hidden="hidden"><?php echo e(trans('entities.page_contents_none')); ?></p>
        <div refs="toolbox-contents@display"></div>
    </div>
</div><?php /**PATH /app/www/resources/views/pages/parts/toolbox-contents.blade.php ENDPATH**/ ?>